import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

export default function WeatherApp() {
  return (
    <View style={styles.container}>
      <Text style={styles.city}>New York, USA</Text>
      <Image
        source={{ uri: 'https://cdn-icons-png.flaticon.com/512/1163/1163661.png' }}
        style={styles.weatherIcon}
      />
      <Text style={styles.temperature}>25°C</Text>
      <Text style={styles.description}>Sunny</Text>
      <View style={styles.extraInfo}>
        <View style={styles.infoBox}>
          <Text style={styles.infoText}>Humidity: 60%</Text>
        </View>
        <View style={styles.infoBox}>
          <Text style={styles.infoText}>Wind: 10 km/h</Text>
        </View>
        <View style={styles.infoBox}>
          <Text style={styles.infoText}>Air Quality: Good (AQI 45)</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#87CEEB',
    padding: 20,
  },
  city: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#FFD700',
    marginBottom: 10,
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10,
  },
  weatherIcon: {
    width: 150,
    height: 150,
    marginVertical: 20,
    borderRadius: 10,
  },
  temperature: {
    fontSize: 72,
    fontWeight: 'bold',
    color: '#FFD700',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: -1, height: 1 },
    textShadowRadius: 10,
  },
  description: {
    fontSize: 28,
    color: '#FFD700',
    marginBottom: 20,
    textTransform: 'capitalize',
    fontStyle: 'italic',
  },
  extraInfo: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '90%',
    marginTop: 20,
  },
  infoBox: {
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 5,
  },
  infoText: {
    fontSize: 20,
    color: '#fff',
    fontWeight: '600',
  },
});
